$(function() {
	// const 변수
    const message = {
    	MAIN_TITLE : 'むりやり　スキャン',
    	ADD_MAIL_TEXT : 'メール追加',
    	MAIL_TITLE : '宛先選択',
    	OK : 'OK',
    	CANCEL : 'Cancel',
    	DOCU : {
    			list : ['DocuWorks', 'PDF', 'TIFF/JPEG自動'],
    			selected : 2
    	},	
    	COLOR : {
    			list : ['自動カラー', '白黒', 'カラー', 'グレイスケール'],
    			selected : 2
    	},
    	MAX_SELECT : 12,
    	FIRST_PAGE : 1,
    	TOTAL_PAGE : Math.ceil((address.length / 10))
    };
    
    // 페이지 정보를 담고 있는 전역 변수
    var currentPage = 2;
    
    // 상태 변수
    // 동사로 시작, 기본값 false
    var isMenuOpen = false;
    
    // onClick... 함수명 초기화
    var 
    	onClickMenu, onClickMenuList, onClickAddMail,
    	onClickOkButton, onClickCancelButton, onClickMailContent,
    	onClickPageButton;
    
    /* 선택된 메일 주소에 대한 index 정보를 저장하는 배열 
     * 이 배열에 저장된 index로 address.js에 선언되어 있는 address 배열에 접근하여
     * 데이터를 가져오고 있다.
     */
    var selectedMailIndex = [];
    
    /* 메뉴 리스트에 텍스트 삽입하는 함수
     * 문자열 배열을 이용하여 초기화함
	 * len : 배열의 길이
	 * target : div를 추가할 부분 
     * arr : 문자열 배열
	 */
    var initListText = function(len, target, obj) {
    	var i;
        for (i = 0; i < len; i++) {
        	// index가 초기 설정한 selected 값과 일치할 때  div에 list-selected 클래스를 추가
        	// 삼항연산자
        	i === obj.selected ? 
        		target.append('<div class="list-selected">' + obj.list[i] + '</div>') : 
        		target.append('<div>' + obj.list[i] + '</div>') 
        }
    };
    
    /* 메인 페이지 텍스트 설정 함수
     * id값이 각각 main-title, add-mail, docu-list, color-list, docu, color,
	 * mail-head, ok, cancel, current-page, total-page인 태그 값 초기화
     */
    var initPageText = (function() {
        $('#main-title').append(message.MAIN_TITLE);
        $('#add-mail').append(message.ADD_MAIL_TEXT);
        initListText(message.DOCU.list.length, $('#docu-list'), message.DOCU);
        initListText(message.COLOR.list.length, $('#color-list'), message.COLOR);
        $('#docu').append(message.DOCU.list[message.DOCU.selected]);
        $('#color').append(message.COLOR.list[message.COLOR.selected]);
        $('#mail-head').append(message.MAIL_TITLE);
        $('#ok').append(message.OK);
        $('#cancel').append(message.CANCEL);
        $('#total-page').append(message.TOTAL_PAGE);
    })();
    
	/* 페이지 전환용 함수
	 * display: block, display: none 스위칭
	 */
    // chgDisplayPage or chgDispPage로 함수명 변경
    var chgDisplayPage = function(showPage, hidePage) {
    	showPage.show();
		hidePage.hide();
		$('#current-page').text(currentPage);
    };
    
    /* menu list를 숨기는 함수 */
    var menuListHide = function() {
    	$('#menu-list>div').hide();
		$('#main-menu>div').removeClass('menu-open');
		$('#main-menu>div').removeClass('disabled');
		$('#add-mail').removeClass('disabled');
		
		isMenuOpen = false;
    };
    
    /* 메뉴 클릭 시 리스트 on/off 함수 
     * menuClosed가 true일 때 선택된 메뉴의 리스트 show
     * 메뉴가 열린 상태에서 다른 메뉴나 메일 추가 버튼을 눌렀을 때
     * 메뉴를 닫는다. 
     * */
    onClickMenu = function(event) {
    	if (isMenuOpen) {
    		// 메뉴의 리스트 hide
    		menuListHide();
		}
    	else {
    		$('#' + event.target.id + '-list').show();
			$(this).addClass('menu-open');
			$('#main-menu>').not($(this)).addClass('disabled');
			$('#add-mail').addClass('disabled');
			isMenuOpen = true;
    	}
    	return false;
    };
    
    /* 메뉴에서 값을 선택했을 때 실행되는 함수 
     * 선택된 값으로 메뉴의 값을 바꿔준다.
     */
    onClickMenuList = function(event) {
    	var textTarget = (event.target.parentNode.id).split('-')[0];
    	$('#'+event.target.parentNode.id + '>div').removeClass('list-selected');
    	$(event.target).addClass('list-selected');
    	$('#'+textTarget).html(event.target.textContent).append('<div id="arrow-down"></div>');
    	$('#'+textTarget).removeClass('active');
    };

	/* 선택된 메일 주소의 색을 변경하기 위한 함수 */
	var selectedMailContent = function() {
		var len = selectedMailIndex.length;
		var i;
		var calcIndex = (currentPage - 1) * 10;
		for(i=0; i<len; i++) {
			$($('#mail-view>div')[selectedMailIndex[i] - calcIndex]).addClass('content-selected');
		}
	};

    /* 메일 추가 버튼을 눌렀을 때 동작하는 함수
     * 페이지 전환을 하면서 초기 메일 주소 10개를 생성한다.
     */
    onClickAddMail = function() {
    	if (! isMenuOpen) {
    		chgDisplayPage($('.mail-page'), $('.main-page'));
    		setMailContent(currentPage);
			selectedMailContent();
			chgBtnOpacity();
		}
    };
    
    /* OK 버튼을 눌렀을 때 동작하는 함수
     * 페이지 전환을 하면서
     * 메인페이지에 선택한 주소를 보여준다.
     */
    onClickOkButton = function(event) {
    	var i;
    	var len = selectedMailIndex.length;
    	$('#main-view').html('');
    	for (i = 0; i<len; i++) {
    		$('#main-view').append('<div id="' + selectedMailIndex[i] + '">'
    			+ address[selectedMailIndex[i]] + '</div>');
    	}
    	chgDisplayPage($('.main-page'), $('.mail-page'));
    };
    
    /* Cancel 버튼을 눌렀을 때 동작하는 함수
     * 먼저 메일 주소의 색을 전부 원래대로 되돌린 다음에
     * 전에 선택되어서 메인페이지에 추가되었던 주소들만
     * 다시 색을 변경해준다. 
     */
    onClickCancelButton = function(event) {
    	var i;
		var len = $('#main-view>div').length;
		var mailContent = $('#main-view>div');
		selectedMailIndex = [];
    	$('#mail-view>div').removeClass('content-selected');
    	for (i = 0; i<len; i++) {
			selectedMailIndex[i] = parseInt(mailContent[i].id);
    	}
		chgDisplayPage($('.main-page'), $('.mail-page'));
		currentPage = 1;
    };
    
    /* 메일 주소 10개를 mail-view 부분에 세팅하는 함수 
     * 정적으로 생성된 10개의 div에 메일 주소 삽입
     * */
    var setMailContent = function(page) {
    	var i;
    	var len = address.length;
    	var startIndex = (page-1) * 10;
    	var endIndex = page * 10;
    	var divIndex = 0;
    	var target = $('#mail-view>div');
    	target.show();
    	if ( page !== message.TOTAL_PAGE) {
    		for (i = startIndex; i < endIndex; i++) {
        		$(target[divIndex++]).html((i+1) + '. ' + address[i]);
        	}
    	}
    	else {
    		for (i = startIndex; i < endIndex; i++) {
    			if (i >= len) {
    				$(target[divIndex++]).hide();
    			}
    			else {
    				$(target[divIndex++]).html((i+1) + '. ' + address[i]);
    			}
    		}
    	}
    };
    
    /* 배열의 특정 요소를 삭제하는 함수 */
    var removeArrayElement = function(arr, element) {
    	var i = arr.indexOf(element);
    	if ( i > -1) {
    		arr.splice(i, 1);
    	}
	};
	
	/* 선택해제 된 메일 주소를 selectedMailIndex 배열에서 삭제 */
	var unselectedMailContent = function(obj, element) {
		obj.removeClass('content-selected');
		removeArrayElement(selectedMailIndex, element);
	};
    
    /* mail-page에서 메일 주소를 눌렀을 때 동작하는 함수
     * 선택되거나 선택해제 될 때 색상과 선택 개수 변경
     */
    onClickMailContent = function(event) {
    	var clickedIndex = $('#' + event.target.parentNode.id + '>div').index($(this));
    	var mailContentIndex = clickedIndex + (currentPage - 1) * 10;
    	if ( $(this).hasClass('content-selected') ) {
    		unselectedMailContent($(this), mailContentIndex);
    	} 
    	else {
    		if ( selectedMailIndex.length === message.MAX_SELECT ) {
    			alert('선택 개수 초과');
    			return;
    		}
    		$(this).addClass('content-selected');
    		selectedMailIndex.push(mailContentIndex);
    	}
    };
	
    /* 페이지 이동 버튼의 투명도를 변경하는 함수 */
    var chgBtnOpacity = function() {
		if (currentPage === 1) {
			$('#first-page').addClass('disabled')
			$('#first-page-arrow').addClass('disabled');
			$('#prev-page').addClass('disabled')
			$('#prev-page-arrow').addClass('disabled');
			$('#last-page').removeClass('disabled')
			$('#last-page-arrow').removeClass('disabled');
			$('#next-page').removeClass('disabled')
			$('#next-page-arrow').removeClass('disabled');
		} else if (currentPage === message.TOTAL_PAGE) {
			$('#last-page').addClass('disabled')
			$('#last-page-arrow').addClass('disabled');
			$('#next-page').addClass('disabled')
			$('#next-page-arrow').addClass('disabled');
			$('#first-page').removeClass('disabled')
			$('#first-page-arrow').removeClass('disabled');
			$('#prev-page').removeClass('disabled')
			$('#prev-page-arrow').removeClass('disabled');
		}
		else {
			$('#first-page').removeClass('disabled')
			$('#first-page-arrow').removeClass('disabled');
			$('#prev-page').removeClass('disabled')
			$('#prev-page-arrow').removeClass('disabled');
			$('#last-page').removeClass('disabled')
			$('#last-page-arrow').removeClass('disabled');
			$('#next-page').removeClass('disabled')
			$('#next-page-arrow').removeClass('disabled');
		}
	};
    
	/* 페이지 변경을 위한 함수 
	 * 현재 페이지, 타겟 페이지, 한계 페이지를 인자로 받아서
	 * 페이징 처리
	 * 타겟 페이지가 첫번째 페이지거나 마지막 페이지 일 경우 경고창 
	 * 아닐 경우 페이지에 맞게 mail-view 내용을 다시 만든다.
	 */
	var pagination = function() {
		$('#mail-view>div').removeClass('content-selected');
		setMailContent(currentPage);
		selectedMailContent();
	};

	/* 페이지 이동 관련 버튼이 눌렸을 때
	 * 눌린 버튼에 해당하는 이동 함수 호출
	 */
	onClickPageButton = function(event) {
		switch (event.currentTarget.id) {
			case 'first-page':
				currentPage = 1;
			break;
			case 'prev-page':
				if (currentPage > 1) {
					currentPage -= 1;
				}
			break;
			case 'next-page':
				if (currentPage !== message.TOTAL_PAGE) {
					currentPage += 1;
				}
			break;
			case 'last-page':
				currentPage = message.TOTAL_PAGE;
			default:
			break;
		}
		$('#current-page').text(currentPage);
		pagination();
		chgBtnOpacity();
	};
    
    /* 메뉴 리스트 창이 열렸을 때 다른 곳을 눌러도 리스트 창이 닫히게 하는 함수
     * 클릭된 영역이 'menu-open' 클래스를 가지고 있지 않을 때
     * menu list를 숨기고 menu-open 클래스를 제거.
     */
	$(document).click(function() {
		if(!$(this).hasClass('menu-open')) {
			menuListHide();
		}
	});
    
    // 클릭했을 때 해당되는 함수 호출
    $('#main-menu>div').click(onClickMenu);
    $('#menu-list>div').click(onClickMenuList);
    $('#add-mail').click(onClickAddMail);
    $('#ok').click(onClickOkButton);
    $('#cancel').click(onClickCancelButton);
	$(document).on('click', '#mail-view>div', onClickMailContent);
	$('#paging>div').click(onClickPageButton);
});