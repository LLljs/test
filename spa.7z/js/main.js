$(function() {
    var title = 'むりやり　スキャン';
    var addMailText = 'メール追加';
    var setTitle = (function() {
        $('#main-title').append(title);
    })();
    var setaddMailText = (function() {
        $('#add-mail').append(addMailText);
    })();
})();