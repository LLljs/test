$(function() {
	// 문자열 상수
    const MAIN_TITLE = 'むりやり　スキャン';
    const ADD_MAIL_TEXT = 'メール追加';
    const MAIL_TITLE = '宛先選択';
    const OK = 'OK';
    const CANCEL = 'Cancel';
    const DOCU = ['DocuWorks', 'PDF', 'TIFF/JPEG自動'];
    const COLOR = ['自動カラー', '白黒', 'カラー', 'グレイスケール'];
    
    // 상태 변수
    var menuClosed = true;
    var initMailContent = false;
    
    /* 선택된 메일 주소에 대한 index 정보를 저장하는 배열
     * 메일 주소가 선택되었을 때 선택된 메일의 index를 배열에 저장한 뒤
     * 그 index 정보를 활용할 수 있다. 
     */
    var selectedMailIndex = [];
    
    /* 메뉴 리스트에 텍스트 삽입하는 함수
     * 문자열 배열을 이용하여 초기화함
     */
    var initListText = function(len, listName, arr) {
    	var i;
        for (i = 0; i < len; i++) {
        	// 배열의 첫번째 요소에 list-selected 라는 class 추가
        	if (i == 0) {
        		listName.append('<div class="list-selected">' + arr[i] + '</div>');
        	}
        	else {
        		listName.append('<div>' + arr[i] + '</div>');
        	}
        }
    };
    
    /* 메인 페이지 텍스트 설정 함수
     * 태그의 id값이 각각 main-title, add-mail, docu-list, color-list, docu, color인
     * 태그에 문자열 상수로 초기값 설정
     */
    var initPageText = (function() {
        $('#main-title').append(MAIN_TITLE);
        $('#add-mail').append(ADD_MAIL_TEXT);
        initListText(DOCU.length, $('#docu-list'), DOCU);
        initListText(COLOR.length, $('#color-list'), COLOR);
        $('#docu').append(DOCU[0]);
        $('#color').append(COLOR[0]);
        $('#mail-head').append(MAIL_TITLE);
        $('#ok').append(OK);
        $('#cancel').append(CANCEL);
        $('#current-page').append(1);
        $('#total-page').append(Math.ceil(address.length / 10));
    })();
    
	/* 페이지 전환용 함수 
	 * 
	 */
    var switchingPage = function(showPage, hidePage) {
    	showPage.show();
		hidePage.hide();
		$('#mail-view>div').remove();
		initMailContent = false;
		$('#current-page').text(1);		
    };
    
    /* 메뉴 클릭 시 리스트 on/off 함수 */
    onClickMenu = function(event) {
    	if (menuClosed) {
    		// 선택된 메뉴의 리스트 show
    		$('#' + event.target.id + '-list').show();
			$('#' + event.target.id).addClass('active');
			$('#add-mail').addClass('active');
    		menuClosed = false;
    	} else {
    		// 선택된 메뉴의 리스트 hide
    		$('#menu-list>div').hide();
    		$('#' + event.target.id).removeClass('active');
			menuClosed = true;
			$('#add-mail').removeClass('active');
    	}
    	return false;
    };
    
    /* 메뉴에서 값을 선택했을 때 실행되는 함수 
     * 선택된 값으로 메뉴의 값을 바꿔준다.
     */
    onClickMenuList = function(event) {
    	var textTarget = (event.target.parentNode.id).split('-')[0];
    	$('#'+event.target.parentNode.id + '>div').removeClass('list-selected');
    	$(event.target).addClass('list-selected');
    	$('#'+textTarget).html(event.target.textContent).append('<div id="arrow-down"></div>');
    	$('#'+textTarget).removeClass('active');
    };

	/* 선택된 메일 주소의 색을 변경하기 위한 함수 */
	var selectedMailContent = function() {
		var len = selectedMailIndex.length;
		var i;
		for(i=0; i<len; i++) {
			$('#mail-view #' + selectedMailIndex[i]).addClass('content-selected');
		}
	};

    /* 메일 추가 버튼을 눌렀을 때 동작하는 함수
     * 페이지 전환을 하면서 초기 메일 주소 10개를 생성한다.
     */
    onClickAddMail = function() {
    	if (menuClosed) {
    		switchingPage($('.mail-page'), $('.main-page'));
    		if( ! initMailContent ) {
				setMailContent(1);
				selectedMailContent();
			}
		}
    };
    
    /* OK 버튼을 눌렀을 때 동작하는 함수
     * 페이지 전환을 하면서
     * 메인페이지에 선택한 주소를 보여준다.
     */
    onClickOkButton = function(event) {
    	var i;
    	var len = selectedMailIndex.length;
    	$('#main-view').html('');
    	for (i = 0; i<len; i++) {
    		$('#main-view').append('<div id="' + selectedMailIndex[i] + '">'
    			+ address[selectedMailIndex[i]] + '</div>');
    	}
    	switchingPage($('.main-page'), $('.mail-page'));
    };
    
    /* Cancel 버튼을 눌렀을 때 동작하는 함수
     * 먼저 메일 주소의 색을 전부 원래대로 되돌린 다음에
     * 전에 선택되어서 메인페이지에 추가되었던 주소들만
     * 다시 색을 변경해준다. 
     */
    onClickCancelButton = function(event) {
    	var i;
		var len = $('#main-view>div').length;
		var mailContent = $('#main-view>div');
		selectedMailIndex = [];
		//counter.setCount(len);
    	$('#mail-view>div').removeClass('content-selected');
    	for (i = 0; i<len; i++) {
			selectedMailIndex[i] = mailContent[i].id;
    		$('#mail-view #' + mailContent[i].id).addClass('content-selected');
    	}
		switchingPage($('.main-page'), $('.mail-page'));
    };
    
    /* 메일 주소 10개를 mail-view 부분에 세팅하는 함수 */
    var setMailContent = function(page) {
    	var i;
    	var len;
    	if (page == $('#total-page').text() ) {
    		len = address.length;
    	} else {
    		len = page * 10;
    	}
    	for (i = (page-1) * 10; i < len; i++) {
    		$('#mail-view').append(
    			'<div id="' + i + '">' + (i+1) + '. '+ address[i] +'</div>');
    	}
    	initMailContent = true;
    };
    
    /* 배열의 특정 요소를 삭제하는 함수 */
    var removeArrayElement = function(arr, index) {
    	var i = arr.indexOf(index);
    	if ( i > -1) {
    		arr.splice(i, 1);
    	}
	};
    
    /* mail-page에서 메일 주소를 눌렀을 때 동작하는 함수
     * 선택되거나 선택해제 될 때 색상과 선택 개수 변경
     */
    onClickMailContent = function(event) {
    	if ( $(this).hasClass('content-selected') ) {
    		$(this).removeClass('content-selected');
    		removeArrayElement(selectedMailIndex, $(this).attr('id'));
    		//counter.decrease();
    	} 
    	else {
    		$(this).addClass('content-selected');
    		selectedMailIndex.push($(this).attr('id'));
    		//counter.increase();
    		if ( selectedMailIndex.length == 13 ) {
    			alert('선택 개수 초과');
    			$(this).removeClass('content-selected');
    			removeArrayElement(selectedMailIndex, $(this).attr('id'));
    			//counter.decrease();
    		}
    	}
    };
	
	/* 페이지 변경을 위한 함수 
	 * 현재 페이지, 타겟 페이지, 한계 페이지를 인자로 받아서
	 * 페이징 처리
	 */
	var changePage = function(currentPage, targetPage, limitPage) {
		if (currentPage != limitPage) {
			$('#mail-view>div').remove();
    		$('#current-page').text(targetPage);
			setMailContent(targetPage);
			selectedMailContent();
		}
		else {
			if (limitPage == 1) {
				alert('첫 페이지');
			}
			else {
				alert('마지막 페이지');
			}
		}
	};

	/* 페이지 이동 관련 버튼이 눌렸을 때
	 * 눌린 버튼에 해당하는 이동 함수 호출
	 */
	onClickPageButton = function(event) {
		var currentPage = parseInt($('#current-page').text());
		var lastPage = parseInt($('#total-page').text());
		var initPage = 1;
		switch (event.target.id) {
			case 'first-page':
			case 'first-page-arrow': 
				changePage(currentPage, initPage, initPage);
			break;
			case 'prev-page':
			case 'prev-page-arrow':
				changePage(currentPage, currentPage-1, 1);
			break;
			case 'next-page':
			case 'next-page-arrow':
				changePage(currentPage, currentPage+1, lastPage);
			break;
			case 'last-page':
			case 'last-page-arrow':
				changePage(currentPage, lastPage, lastPage);
			default:
			break;
		}
	};
    
    /* 클릭 카운터를 위한 함수 */
	// var counter = (function() {
	// 	var count = 0;
	// 	function changeCount(number) {
	// 		count += number;
	// 	}
	// 	return {
	// 		increase: function() { // 증가 함수
	// 			changeCount(1);
	// 		},
	// 		decrease: function() { // 감소 함수
	// 			changeCount(-1);
	// 		},
	// 		init: function() { // 초기화 함수
	// 			count = 0;
	// 		},
	// 		getCount: function() { // getter
	// 			return count;
	// 		},
	// 		setCount: function(num) { // setter
	// 			count = num;
	// 		}
	// 	}
	// })();
    
    // 메뉴 리스트 창이 열렸을 때 다른 곳을 눌러도 리스트 창이 닫히게 하는 함수
    $(document).click(function(event) {
		if (!(event.target.id == 'docu' || event.target.id == 'color')) {
			$('#menu-list>div').hide();
			$('#main-menu>div').removeClass('active');
			$('#add-mail').removeClass('active');
			menuClosed = true;
			return false;
		}
		return false;
	});
    
    // 메뉴 클릭 함수 호출
    $('#main-menu>div').click(onClickMenu);
    $('#menu-list>div').click(onClickMenuList);
    $('#add-mail').click(onClickAddMail);
    $('#ok').click(onClickOkButton);
    $('#cancel').click(onClickCancelButton);
	$(document).on('click', '#mail-view>div', onClickMailContent);
	$('#paging>div').click(onClickPageButton);
});