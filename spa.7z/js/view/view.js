/**
 *  데모 spa 어플리케이션 view
 */
// 페이지 정보를 담고 있는 전역 변수
var currentPage = 2

/* 선택된 메일 주소에 대한 index 정보를 저장하는 배열 
 * 이 배열에 저장된 index로 address.js에 선언되어 있는 address 배열에 접근하여
 * 데이터를 가져오고 있다.
 */
var selectedMailIndex = [];

/* 메뉴 리스트에 텍스트 삽입하는 함수
 * 문자열 배열을 이용하여 초기화함
 * len : 배열의 길이
 * target : div를 추가할 부분 
 * arr : 문자열 배열
 */
var initListText = function(len, target, obj) {
	var i;
    for (i = 0; i < len; i++) {
    	// index가 초기 설정한 selected 값과 일치할 때  div에 list-selected 클래스를 추가
    	i === obj.selected ? 
    		target.append('<div class="list-selected">' + obj.list[i] + '</div>') : 
    		target.append('<div>' + obj.list[i] + '</div>') 
    }
};

/* 메인 페이지 텍스트 설정 함수
 * id값이 각각 main-title, add-mail, docu-list, color-list, docu, color,
 * mail-head, ok, cancel, current-page, total-page인 태그 값 초기화
 */
var initPageText = function() {
    $('#main-title').append(message.MAIN_TITLE);
    $('#add-mail').append(message.ADD_MAIL_TEXT);
    initListText(message.DOCU.list.length, $('#docu-list'), message.DOCU);
    initListText(message.COLOR.list.length, $('#color-list'), message.COLOR);
    $('#docu').append(message.DOCU.list[message.DOCU.selected]);
    $('#color').append(message.COLOR.list[message.COLOR.selected]);
    $('#mail-head').append(message.MAIL_TITLE);
    $('#ok').append(message.OK);
    $('#cancel').append(message.CANCEL);
    $('#total-page').append(message.TOTAL_PAGE);
};

/* menu list를 숨기는 함수 */
var menuListHide = function() {
	$('#menu-list>div').hide();
	$('#main-menu>div').removeClass('menu-open');
	$('#main-menu>div').removeClass('disabled');
	$('#add-mail').removeClass('disabled');
};

/* 페이지 전환용 함수
 * display: block, display: none 스위칭
 */
var chgDisplayPage = function(showPage, hidePage) {
	showPage.show();
	hidePage.hide();
	$('#current-page').text(currentPage);
};

/* 선택된 메일 주소의 색을 변경하기 위한 함수 */
var selectedMailContent = function() {
	var len = selectedMailIndex.length;
	var i;
	var calcIndex = (currentPage - 1) * 10;
	for(i=0; i<len; i++) {
		$($('#mail-view>div')[selectedMailIndex[i] - calcIndex]).addClass('content-selected');
	}
};

/* 메일 주소 10개를 mail-view 부분에 세팅하는 함수 
 * 정적으로 생성된 10개의 div에 메일 주소 삽입
 * */
var setMailContent = function(page) {
	var i;
	var addressLength = address.length;
	var startIndex = (page-1) * 10;
	var endIndex = page * 10;
	var divIndex = 0;
	var target = $('#mail-view>div');
	target.show();
	for (i = startIndex; i < endIndex; i++) {
		if (i >= addressLength) {
			$(target[divIndex++]).hide();
		} else {
			$(target[divIndex++]).html((i + 1) + '. ' + address[i]);
		}
	}
};

/* 페이지 이동 버튼의 투명도를 변경하는 함수 */
var chgBtnOpacity = function() {
	if (currentPage === 1) {
		$('#first-page').addClass('disabled')
		$('#first-page-arrow').addClass('disabled');
		$('#prev-page').addClass('disabled')
		$('#prev-page-arrow').addClass('disabled');
		$('#last-page').removeClass('disabled')
		$('#last-page-arrow').removeClass('disabled');
		$('#next-page').removeClass('disabled')
		$('#next-page-arrow').removeClass('disabled');
	} else if (currentPage === message.TOTAL_PAGE) {
		$('#last-page').addClass('disabled')
		$('#last-page-arrow').addClass('disabled');
		$('#next-page').addClass('disabled')
		$('#next-page-arrow').addClass('disabled');
		$('#first-page').removeClass('disabled')
		$('#first-page-arrow').removeClass('disabled');
		$('#prev-page').removeClass('disabled')
		$('#prev-page-arrow').removeClass('disabled');
	}
	else {
		$('#first-page').removeClass('disabled')
		$('#first-page-arrow').removeClass('disabled');
		$('#prev-page').removeClass('disabled')
		$('#prev-page-arrow').removeClass('disabled');
		$('#last-page').removeClass('disabled')
		$('#last-page-arrow').removeClass('disabled');
		$('#next-page').removeClass('disabled')
		$('#next-page-arrow').removeClass('disabled');
	}
};

/* 배열의 특정 요소를 삭제하는 함수 */
var removeArrayElement = function(arr, element) {
	var i = arr.indexOf(element);
	if ( i > -1) {
		arr.splice(i, 1);
	}
};

/* 선택해제 된 메일 주소를 selectedMailIndex 배열에서 삭제 */
var unselectedMailContent = function(obj, element) {
	obj.removeClass('content-selected');
	removeArrayElement(selectedMailIndex, element);
};

/* 페이지 변경을 위한 함수 
 * 현재 페이지, 타겟 페이지, 한계 페이지를 인자로 받아서
 * 페이징 처리
 * 타겟 페이지가 첫번째 페이지거나 마지막 페이지 일 경우 경고창 
 * 아닐 경우 페이지에 맞게 mail-view 내용을 다시 만든다.
 */
var pagination = function() {
	$('#mail-view>div').removeClass('content-selected');
	setMailContent(currentPage);
	selectedMailContent();
};

/* 메뉴 리스트 창이 열렸을 때 다른 곳을 눌러도 리스트 창이 닫히게 하는 함수
 * 클릭된 영역이 'menu-open' 클래스를 가지고 있지 않을 때
 * menu list를 숨기고 menu-open 클래스를 제거.
 */
$(document).click(function() {
	if(!$(this).hasClass('menu-open')) {
		menuListHide();
	}
});