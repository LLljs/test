/**
 * 데모 spa 어플리케이션 model
 */

/* 메일 주소를 저장하고 있는 배열 */
var address = [
	"test1qwerasdfzxcv123456789@test.fujixerox.com",
	"test2@test.fujixerox.com",
	"test3@test.fujixerox.com",
	"test4@test.fujixerox.com",
	"test5@test.fujixerox.com",
	"test6@test.fujixerox.com",
	"test7@test.fujixerox.com",
	"test8@test.fujixerox.com",
	"test9@test.fujixerox.com",
	"test10@test.fujixerox.com",
	"test11@test.fujixerox.com",
	"test12@test.fujixerox.com",
	"test13@test.fujixerox.com",
	"test14@test.fujixerox.com",
	"test15@test.fujixerox.com",
	"test16@test.fujixerox.com",
	"test17@test.fujixerox.com",
	"test18@test.fujixerox.com",
	"test19@test.fujixerox.com",
	"test20@test.fujixerox.com",
	"test21@test.fujixerox.com",
	"test22@test.fujixerox.com",
	"test23@test.fujixerox.com",
	"test24@test.fujixerox.com",
	"test25@test.fujixerox.com",
	"test26@test.fujixerox.com",
	"test27@test.fujixerox.com",
	"test28@test.fujixerox.com",
	"test29@test.fujixerox.com",
	"test30@test.fujixerox.com",
	"test31@test.fujixerox.com",
	"test32@test.fujixerox.com",
	"test33@test.fujixerox.com",
	"test34@test.fujixerox.com",
	"test35@test.fujixerox.com",
	"test36@test.fujixerox.com"
];

const message = {
	/* message */
	MAIN_TITLE : 'むりやり　スキャン',
	ADD_MAIL_TEXT : 'メール追加',
	MAIL_TITLE : '宛先選択',
	OK : 'OK',
	CANCEL : 'Cancel',
	MAX_SELECT : 12,
	FIRST_PAGE : 1,
	TOTAL_PAGE : Math.ceil((address.length / 10)),
	/* menu-list에 사용할 문자열 배열과 초기 선택 index 설정 */
	DOCU : {
		list : [ 'DocuWorks', 'PDF', 'TIFF/JPEG自動' ],
		selected : 1
	},
	COLOR : {
		list : [ '自動カラー', '白黒', 'カラー', 'グレイスケール' ],
		selected : 3
	}
};