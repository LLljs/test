/*
 *  spa 데모 어플리케이션 controller
 */

/** onClick...함수명 초기화 */
var
	onClickMenu, onClickMenuList, onClickAddMail,
	onClickOkButton, onClickCancelButton, onClickMailContent,
	onClickPageButton;

/** function : onClickMenu
 * 메뉴 클릭 시 리스트 on/off 함수 
 * menu-list의 display 속성이 모두 none일 때
 * 선택된 메뉴의 리스트 show
 * 메뉴가 열린 상태에서 다른 메뉴나 메일 추가 버튼을 눌렀을 때
 * 메뉴를 닫는다. 
 * */
onClickMenu = function (event) {
	var targetId = event.target.id.split('-')[0];
	$('#' + targetId + '-arrow').addClass('reverse');
	if (($('#docu-list').css('display') === 'none') &&
		($('#color-list').css('display') === 'none')) {
		$('#' + targetId + '-list').show();
		$(this).addClass('menu-open');
		$('#main-menu>').not($(this)).addClass('disabled');
		$('#add-mail').addClass('disabled');
	}
	else {
		menuListHide();
	}
	return false;
};

/** function : onClickMenuList 
 * 메뉴에서 값을 선택했을 때 실행되는 함수 
 * 선택된 값으로 메뉴의 값을 바꿔준다.
 */
onClickMenuList = function (event) {
	var menuName = event.currentTarget.id.split('-')[0];
	$('#' + event.currentTarget.id + '>div').removeClass('list-selected');
	$(event.target).addClass('list-selected');
	$('#' + menuName).html(event.target.textContent).append('<div id="' + menuName + '-arrow"></div>');
	$('#' + menuName).removeClass('active');
	$('#' + menuName + '-arrow').removeClass('reverse');
};

/** function : onClickAddMail
 * 메일 추가 버튼을 눌렀을 때 동작하는 함수
 * 페이지 전환을 하면서 currentPage의 메일 주소 10개를 생성한다.
 */
onClickAddMail = function () {
	if (!$(this).hasClass('disabled')) {
		chgDisplayPage($('.mail-page'), $('.main-page'));
		setMailContent(currentPage);
		selectedMailContent();
		chgBtnOpacity();
	}
};

/** function : onClickOkButton
 * OK 버튼을 눌렀을 때 동작하는 함수
 * 페이지 전환을 하면서 메인페이지에 선택한 주소를 보여준다.
 */
onClickOkButton = function (event) {
	var i;
	var len = selectedMailIndex.length;
	$('#main-view').html('');
	for (i = 0; i < len; i++) {
		$('#main-view').append('<div id="' + selectedMailIndex[i] + '">'
			+ address[selectedMailIndex[i]] + '</div>');
	}
	chgDisplayPage($('.main-page'), $('.mail-page'));
};

/** function : onClickCancelButton
 * Cancel 버튼을 눌렀을 때 동작하는 함수
 * 먼저 메일 주소의 색을 전부 원래대로 되돌린 다음에
 * 전에 선택되어서 메인페이지에 추가되었던 주소들만
 * 다시 색을 변경해준다. 
 */
onClickCancelButton = function (event) {
	var i;
	var len = $('#main-view>div').length;
	var mailContent = $('#main-view>div');
	selectedMailIndex = [];
	$('#mail-view>div').removeClass('content-selected');
	for (i = 0; i < len; i++) {
		selectedMailIndex[i] = parseInt(mailContent[i].id);
	}
	chgDisplayPage($('.main-page'), $('.mail-page'));
	currentPage = 1;
};

/** function : onClickMailContent
 *  mail-page에서 메일 주소를 눌렀을 때 동작하는 함수
 *  선택되거나 선택해제 될 때 색상과 선택 개수 변경
 */
onClickMailContent = function (event) {
	var clickedIndex = $('#' + event.target.parentNode.id + '>div').index($(this));
	var mailContentIndex = clickedIndex + (currentPage - 1) * 10;
	if ($(this).hasClass('content-selected')) {
		unselectedMailContent($(this), mailContentIndex);
	}
	else {
		if (selectedMailIndex.length === message.MAX_SELECT) {
			alert('선택 개수 초과');
			return;
		}
		$(this).addClass('content-selected');
		selectedMailIndex.push(mailContentIndex);
	}
};

/** function : onClickPageButton 
 * 페이지 이동 관련 버튼이 눌렸을 때
 * first-page 클릭 -> currentPage를 1로 변경
 * prev-page 클릭 -> currentPage가 1보다 클 때 currentPage 1 감소
 * next-page 클릭 -> currentPage가 마지막 페이지가 아닐 때 currentPage 1 증가
 * last-page 클릭 -> currentPage를 마지막 페이지로 변경
 * 페이지 설정 case문 실행 후 currentPage 표시 변경, 
 * pagination(), chgBtnOpacity() 함수 호출
 */
onClickPageButton = function (event) {
	switch (event.currentTarget.id) {
		case 'first-page':
			currentPage = 1;
			break;
		case 'prev-page':
			if (currentPage > 1) {
				currentPage -= 1;
			}
			break;
		case 'next-page':
			if (currentPage !== message.TOTAL_PAGE) {
				currentPage += 1;
			}
			break;
		case 'last-page':
			currentPage = message.TOTAL_PAGE;
		default:
			break;
	}
	$('#current-page').text(currentPage);
	pagination();
	chgBtnOpacity();
};