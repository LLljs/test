/**
 * spa 데모 어플리케이션 main.js
 */

/** initPageText 함수 호출 및
 *  click 이벤트 시 함수호출
 */
$(function () {
    initPageText();
    $('#main-menu>div').click(onClickMenu);
    $('#menu-list>div').click(onClickMenuList);
    $('#add-mail').click(onClickAddMail);
    $('#ok').click(onClickOkButton);
    $('#cancel').click(onClickCancelButton);
    $('#mail-view>div').click(onClickMailContent);
    $('#paging>div').click(onClickPageButton);
});