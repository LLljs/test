/*
 *  spa 데모 어플리케이션 controller
 */

var controller = {
	/** function : onClickMenu
	 * 메뉴 클릭 시 리스트 on/off 함수 
	 * menu-list의 display 속성이 모두 none일 때
	 * 선택된 메뉴의 리스트 show
	 * 메뉴가 열린 상태에서 다른 메뉴나 메일 추가 버튼을 눌렀을 때
	 * 메뉴를 닫는다. 
	 * */
	onClickMenu: function (event) {
		var targetId = event.target.id.split('-')[0];
		$('#' + targetId + '-arrow').addClass('reverse');
		if (($('#docu-list').css('display') === 'none') &&
			($('#color-list').css('display') === 'none')) {
			$('#' + targetId + '-list').show();
			$(this).addClass('menu-open');
			$('#main-menu>').not($(this)).addClass('disabled');
			$('#add-mail').addClass('disabled');
		}
		else {
			view.menuListHide();
		}
		return false;
	},

	/** function : onClickMenuList 
	 * 메뉴에서 값을 선택했을 때 실행되는 함수 
	 * 선택된 값으로 메뉴의 값을 바꿔준다.
	 */
	onClickMenuList: function (event) {
		var menuName = event.currentTarget.id.split('-')[0];
		$('#' + event.currentTarget.id + '>div').removeClass('list-selected');
		$(event.target).addClass('list-selected');
		$('#' + menuName).html(event.target.textContent).append('<div id="' + menuName + '-arrow"></div>');
		$('#' + menuName).removeClass('active');
		$('#' + menuName + '-arrow').removeClass('reverse');
	},

	/** function : onClickAddMail
	 * 메일 추가 버튼을 눌렀을 때 동작하는 함수
	 * 페이지 전환을 하면서 currentPage의 메일 주소 10개를 생성한다.
	 */
	onClickAddMail: function () {
		if (!$(this).hasClass('disabled')) {
			view.chgDisplayPage($('.mail-page'), $('.main-page'));
			view.setMailContent(view.currentPage);
			view.selectedMailContent();
			view.chgBtnOpacity();
		}
	},

	/** function : onClickOkButton
	 * OK 버튼을 눌렀을 때 동작하는 함수
	 * 페이지 전환을 하면서 메인페이지에 선택한 주소를 보여준다.
	 */
	onClickOkButton: function (event) {
		var i;
		var len = model.selectedMailIndex.length;
		$('#main-view').html('');
		for (i = 0; i < len; i++) {
			$('#main-view').append('<div id="' + model.selectedMailIndex[i] + '">'
				+ model.address[model.selectedMailIndex[i]] + '</div>');
		}
		view.chgDisplayPage($('.main-page'), $('.mail-page'));
	},

	/** function : onClickCancelButton
	 * Cancel 버튼을 눌렀을 때 동작하는 함수
	 * 먼저 메일 주소의 색을 전부 원래대로 되돌린 다음에
	 * 전에 선택되어서 메인페이지에 추가되었던 주소들만
	 * 다시 색을 변경해준다. 
	 */
	onClickCancelButton: function (event) {
		var i;
		var len = $('#main-view>div').length;
		var mailContent = $('#main-view>div');
		model.selectedMailIndex = [];
		$('#mail-view>div').removeClass('content-selected');
		for (i = 0; i < len; i++) {
			model.selectedMailIndex[i] = parseInt(mailContent[i].id);
		}
		view.chgDisplayPage($('.main-page'), $('.mail-page'));
		view.currentPage = 1;
	},

	/** function : onClickMailContent
	 *  mail-page에서 메일 주소를 눌렀을 때 동작하는 함수
	 *  선택되거나 선택해제 될 때 색상과 선택 개수 변경
	 */
	onClickMailContent: function (event) {
		var clickedIndex = $('#' + event.target.parentNode.id + '>div').index($(this));
		var mailContentIndex = clickedIndex + (view.currentPage - 1) * 10;
		if ($(this).hasClass('content-selected')) {
			view.unselectedMailContent($(this), mailContentIndex);
		}
		else {
			if (model.selectedMailIndex.length === view.message.MAX_SELECT) {
				alert('선택 개수 초과');
				return;
			}
			$(this).addClass('content-selected');
			model.selectedMailIndex.push(mailContentIndex);
		}
	},

	/** function : onClickPageButton 
	 * 페이지 이동 관련 버튼이 눌렸을 때
	 * first-page 클릭 -> currentPage를 1로 변경
	 * prev-page 클릭 -> currentPage가 1보다 클 때 currentPage 1 감소
	 * next-page 클릭 -> currentPage가 마지막 페이지가 아닐 때 currentPage 1 증가
	 * last-page 클릭 -> currentPage를 마지막 페이지로 변경
	 * 페이지 설정 case문 실행 후 currentPage 표시 변경, 
	 * pagination(), chgBtnOpacity() 함수 호출
	 */
	onClickPageButton: function (event) {
		switch (event.currentTarget.id) {
			case 'first-page':
				view.currentPage = 1;
				break;
			case 'prev-page':
				if (view.currentPage > 1) {
					view.currentPage -= 1;
				}
				break;
			case 'next-page':
				if (view.currentPage !== view.message.TOTAL_PAGE) {
					view.currentPage += 1;
				}
				break;
			case 'last-page':
				view.currentPage = view.message.TOTAL_PAGE;
			default:
				break;
		}
		$('#current-page').text(view.currentPage);
		view.pagination();
		view.chgBtnOpacity();
	},

	/* 메뉴 리스트 창이 열렸을 때 다른 곳을 눌러도 리스트 창이 닫히게 하는 함수
		 * 클릭된 영역이 'menu-open' 클래스를 가지고 있지 않을 때
		 * menu list를 숨기고 menu-open 클래스를 제거.
		 */
	onClickDocument: function () {
		if (!$(this).hasClass('menu-open')) {
			view.menuListHide();
			$('#main-menu').find('div').removeClass('reverse');
		}
	},

	clickEvent: function () {
		$('#main-menu>div').click(this.onClickMenu);
		$('#menu-list>div').click(this.onClickMenuList);
		$('#add-mail').click(this.onClickAddMail);
		$('#ok').click(this.onClickOkButton);
		$('#cancel').click(this.onClickCancelButton);
		$('#mail-view>div').click(this.onClickMailContent);
		$('#paging>div').click(this.onClickPageButton);
		$(document).click(this.onClickDocument);
	}
}