/**
 * 데모 spa 어플리케이션 model
 */

var model = {
	/** 메일 주소를 저장하고 있는 배열 */
	address: [
		"test1qwerasdfzxcv1234@test.fujixerox.com",
		"test2@test.fujixerox.com",
		"test3@test.fujixerox.com",
		"test4@test.fujixerox.com",
		"test5@test.fujixerox.com",
		"test6@test.fujixerox.com",
		"test7@test.fujixerox.com",
		"test8@test.fujixerox.com",
		"test9@test.fujixerox.com",
		"test10@test.fujixerox.com",
		"test11@test.fujixerox.com",
		"test12@test.fujixerox.com",
		"test13@test.fujixerox.com",
		"test14@test.fujixerox.com",
		"test15@test.fujixerox.com",
		"test16@test.fujixerox.com",
		"test17@test.fujixerox.com",
		"test18@test.fujixerox.com",
		"test19@test.fujixerox.com",
		"test20@test.fujixerox.com",
		"test21@test.fujixerox.com",
		"test22@test.fujixerox.com",
		"test23@test.fujixerox.com",
		"test24@test.fujixerox.com",
		"test25@test.fujixerox.com",
		"test26@test.fujixerox.com",
		"test27@test.fujixerox.com",
		"test28@test.fujixerox.com",
		"test29@test.fujixerox.com",
		"test30@test.fujixerox.com",
		"test31@test.fujixerox.com",
		"test32@test.fujixerox.com",
		"test33@test.fujixerox.com",
		"test34@test.fujixerox.com",
		"test35@test.fujixerox.com",
		"test36@test.fujixerox.com"
	],
	/** 선택된 메일 주소에 대한 index 정보를 저장하는 배열 
	 * 이 배열에 저장된 index로 address.js에 선언되어 있는 address 배열에 접근하여
	 * 데이터를 가져온다.
	 */
	selectedMailIndex: []
}
