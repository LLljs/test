/**
 *  데모 spa 어플리케이션 view
 * 	작성자 : 이종석
 */

var view = {

	/** 초기 설정값을 가지고 있는 객체 */
	message: {
		/** message */
		MAIN_TITLE: 'むりやり　スキャン',
		ADD_MAIL_TEXT: 'メール追加',
		MAIL_TITLE: '宛先選択',
		OK: 'OK',
		CANCEL: 'Cancel',
		MAX_SELECT: 12,
		FIRST_PAGE: 1,
		TOTAL_PAGE: Math.ceil(model.address.length / 10),
		/** menu-list에 사용할 문자열 배열과 초기 선택 index 설정 */
		DOCU: {
			list: ['DocuWorks', 'PDF', 'TIFF/JPEG自動'],
			selected: 2
		},
		COLOR: {
			list: ['自動カラー', '白黒', 'カラー', 'グレイスケール'],
			selected: 2
		}
	},

	/** 페이지 정보를 담고 있는 전역 변수 */
	currentPage: 4,

	/** function : initListText
	 * 메뉴 리스트에 텍스트 삽입하는 함수
	 * 문자열 배열을 이용하여 초기화함
	 * len : 배열의 길이
	 * target : div를 추가할 부분 
	 * obj : 문자열 배열
	 */
	initListText: function (len, target, obj) {
		var i;
		for (i = 0; i < len; i++) {
			/** index가 초기 설정한 selected 값과 일치할 때  div에 list-selected 클래스를 추가 */
			i === obj.selected ?
				target.append('<div class="list-selected">' + obj.list[i] + '</div>') :
				target.append('<div>' + obj.list[i] + '</div>')
		}
	},

	/** function : initPageText 
	 * 메인 페이지 텍스트 설정 함수
	 * id값이 각각 main-title, add-mail, docu-list, color-list, docu, color,
	 * mail-head, ok, cancel, current-page, total-page인 태그 값 초기화
	 */
	initPageText: function () {
		$('#main-title').append(this.message.MAIN_TITLE);
		$('#add-mail').append(this.message.ADD_MAIL_TEXT);
		this.initListText(this.message.DOCU.list.length, $('#docu-list'), this.message.DOCU);
		this.initListText(this.message.COLOR.list.length, $('#color-list'), this.message.COLOR);
		$('#docu').append(this.message.DOCU.list[this.message.DOCU.selected]);
		$('#color').append(this.message.COLOR.list[this.message.COLOR.selected]);
		$('#mail-head').append(this.message.MAIL_TITLE);
		$('#ok').append(this.message.OK);
		$('#cancel').append(this.message.CANCEL);
		$('#total-page').append(this.message.TOTAL_PAGE);
	},

	/** function : menuListHide 
	 * menu list를 숨기는 함수 */
	menuListHide: function () {
		$('#menu-list>div').hide();
		$('#main-menu>div').removeClass('menu-open');
		$('#main-menu>div').removeClass('disabled');
		$('#add-mail').removeClass('disabled');
		$('#main-menu').find('div').removeClass('reverse');
	},

	/** function : chgDisplayPage 
	 * 페이지 전환용 함수
	 * showPage : 보여줄 페이지
	 * hidePage : 숨길 페이지
	 * display: block, display: none 스위칭
	 */
	chgDisplayPage: function (showPage, hidePage) {
		showPage.show();
		hidePage.hide();
		$('#current-page').text(view.currentPage);
	},

	/** function : selectedMailContent 
	 * 선택된 메일 주소의 색을 변경하기 위한 함수 */
	selectedMailContent: function () {
		var len = model.selectedMailIndex.length;
		var i;
		var calcIndex = (view.currentPage - 1) * 10;
		for (i = 0; i < len; i++) {
			$($('#mail-view>div')[model.selectedMailIndex[i] - calcIndex]).addClass('content-selected');
		}
	},

	/** function : setMailContent 
	 * 정적으로 생성된 10개의 div에 메일 주소 삽입
	 * page : 10개 주소의 index를 결정하는 page정보
	 * */
	setMailContent: function (page) {
		var i;
		var addressLength = model.address.length;
		var startIndex = (page - 1) * 10;
		var endIndex = page * 10;
		var divIndex = 0;
		var target = $('#mail-view>div');
		target.show();
		for (i = startIndex; i < endIndex; i++) {
			if (i >= addressLength) {
				$(target[divIndex++]).hide();
			} else {
				$(target[divIndex++]).html((i + 1) + '. ' + model.address[i]);
			}
		}
	},

	/** function : chgBtnOpacity
	 * 페이지 이동 버튼의 투명도를 변경하는 함수
	 * 현재 페이지가 첫 페이지일 경우 -> 이전 페이지, 첫 페이지 이동 버튼 비활성화
	 * 현재 페이지가 마지막 페이지일 경우 -> 다음 페이지, 마지막 페이지 이동 버튼 비활성화
	 * 상기 이외의 경우 -> 모든 이동 버튼 활성화
	 * */
	chgBtnOpacity: function () {
		if (view.currentPage === 1) {
			$('div[id^=first-page]').addClass('disabled');
			$('div[id^=prev-page]').addClass('disabled');
			$('div[id^=next-page]').removeClass('disabled');
			$('div[id^=last-page]').removeClass('disabled');
		} else if (view.currentPage === view.message.TOTAL_PAGE) {
			$('div[id^=first-page]').removeClass('disabled');
			$('div[id^=prev-page]').removeClass('disabled');
			$('div[id^=next-page]').addClass('disabled');
			$('div[id^=last-page]').addClass('disabled');
		}
		else {
			$('#paging').find('div').removeClass('disabled');
		}
	},

	/** function : removeArrayElement 
	 * 배열의 특정 요소를 삭제하는 함수 */
	removeArrayElement: function (arr, element) {
		var i = arr.indexOf(element);
		if (i > -1) {
			arr.splice(i, 1);
		}
	},

	/** function : unselectedMailContent
	 * 선택해제 된 메일 주소를 selectedMailIndex 배열에서 삭제 */
	unselectedMailContent: function (obj, element) {
		obj.removeClass('content-selected');
		this.removeArrayElement(model.selectedMailIndex, element);
	},

	/* 페이지 변경을 위한 함수 
	 * 현재 페이지, 타겟 페이지, 한계 페이지를 인자로 받아서
	 * 페이징 처리
	 * 타겟 페이지가 첫번째 페이지거나 마지막 페이지 일 경우 경고창 
	 * 아닐 경우 페이지에 맞게 mail-view 내용을 다시 만든다.
	 */
	pagination: function () {
		$('#mail-view>div').removeClass('content-selected');
		this.setMailContent(view.currentPage);
		this.selectedMailContent();
	}
}