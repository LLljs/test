/**
 * spa 데모 어플리케이션 main.js
 */

/** initPageText 함수 호출 및
 *  click 이벤트 시 함수호출
 */
$(function () {
    view.initPageText();
    controller.clickEvent();
});